package com.example.virtualnumber.model.rent.rentNumberResponse

data class PhoneDetails(
    val id: Int,
    val endDate: String,
    val number: String
)