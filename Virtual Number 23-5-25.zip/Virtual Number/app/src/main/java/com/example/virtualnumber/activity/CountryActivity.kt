package com.example.virtualnumber.activity

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.virtualnumber.R
import com.example.virtualnumber.adapter.CountryAdapter
import com.example.virtualnumber.adapter.RentCountryAdapter
import com.example.virtualnumber.adapter.ServiceSpecificCountryAdapter
import com.example.virtualnumber.databinding.ActivityCountryBinding
import com.example.virtualnumber.remote.NetworkResult
import com.example.virtualnumber.utils.AppPreferences
import com.example.virtualnumber.viewModel.VirtualNumberViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@AndroidEntryPoint
class CountryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCountryBinding
    private lateinit var adapter: CountryAdapter
    private lateinit var serviceSpecificAdapter: ServiceSpecificCountryAdapter
    private lateinit var rentCountryAdapter: RentCountryAdapter

    private val viewModel: VirtualNumberViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCountryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 1) Read serviceCode and serviceName from the Intent
        val serviceCode = intent.getStringExtra("serviceCode") ?: getString(R.string.unknown)
        val serviceName = intent.getStringExtra("serviceName") ?: getString(R.string.unknown)
        val countryInfo = "$serviceName ($serviceCode)"

        // 2) The “matched” ArrayList<String> we passed from RentFragment (if any)
        val matchedNames: ArrayList<String>? = intent.getStringArrayListExtra("MATCHED_NAMES")
        val rentServiceCode = intent.getStringExtra("SERVICE_CODE")

        binding.tvTitle.text = countryInfo
        AppPreferences.setServiceName(serviceName)

        // 3) Back button just finishes this Activity
        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // no op
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s.toString()
                when {
                    ::adapter.isInitialized -> adapter.filter(query)
                    ::serviceSpecificAdapter.isInitialized -> serviceSpecificAdapter.filter(query)
                    ::rentCountryAdapter.isInitialized -> {
                        // If RentCountryAdapter doesn't support filtering yet,
                        // you may want to implement it or just ignore here
                    }
                }
            }

            override fun afterTextChanged(s: Editable?) {
                // no op
            }
        })

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s.toString()

                when {
                    ::adapter.isInitialized -> {
                        adapter.filter(query)
                    }

                    ::serviceSpecificAdapter.isInitialized -> {

                    }

                    ::rentCountryAdapter.isInitialized -> {

                    }
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        })



        // 4) First check: if matchedNames is non-null and non-empty, show that
        if (!matchedNames.isNullOrEmpty()) {
            // a) We have an ArrayList<String> of matched country names from RentFragment.
            //    Just display those names in a simple RecyclerView.
            binding.loading.isVisible = false
            binding.rvCountries.layoutManager = LinearLayoutManager(this)

            // Initialize NameOnlyAdapter with the matched names
            rentCountryAdapter = RentCountryAdapter(this@CountryActivity, matchedNames, rentServiceCode.toString())
            binding.rvCountries.adapter = rentCountryAdapter

            return
        }

        // 5) Depending on serviceName, set up the appropriate RecyclerView + adapter + LiveData
        if (serviceName == "Full rent") {
            // --- “Full rent” branch: use CountryAdapter + viewModel.getCountries(...) + observe countriesResponse ---
            binding.rvCountries.layoutManager = LinearLayoutManager(this)
            adapter = CountryAdapter(this){ isEmpty ->
                binding.tvNoData.isVisible = isEmpty
            }
            binding.rvCountries.adapter = adapter

            lifecycleScope.launch {
                viewModel.getCountries(getString(R.string.smsActivate_api_key))
                viewModel.countriesResponse.observe(this@CountryActivity) { response ->
                    when (response) {
                        is NetworkResult.Success -> {
                            binding.loading.isVisible = false
                            val countries = response.data?.values
                            if (!countries.isNullOrEmpty()) {
                                Log.d("countriesCheck", "countries list size: ${countries.size}")
                                adapter.submitList(countries.toList())
                            } else {
                                Log.d("countriesCheck", "countries list is empty or null")
                            }
                        }

                        is NetworkResult.Error -> {
                            binding.loading.isVisible = false
                            Log.d("countriesCheck", "Error: ${response.message}")
                        }

                        is NetworkResult.Loading -> {
                            Log.d("RentFragment", "Loading rent services...")
                            binding.loading.isVisible = true
                        }
                    }
                }
            }

        } else {
            // --- “Service‐specific” branch: use ServiceSpecificCountryAdapter + viewModel.getServiceSpecificCountries(...) + collect Flow ---
            binding.rvCountries.layoutManager = LinearLayoutManager(this)
            // Initialize with an empty list; it will be updated once data arrives
            serviceSpecificAdapter = ServiceSpecificCountryAdapter(this, emptyList())
            binding.rvCountries.adapter = serviceSpecificAdapter

            // 3a) First, collect any initial Flow of “countries” if needed
            lifecycleScope.launch {
                viewModel.countries.collect { countriesList ->
                    withContext(Dispatchers.Main) {
                        binding.rvCountries.layoutManager =
                            LinearLayoutManager(this@CountryActivity)
                        serviceSpecificAdapter =
                            ServiceSpecificCountryAdapter(this@CountryActivity, countriesList)
                        binding.rvCountries.adapter = serviceSpecificAdapter
                    }
                }
            }

            // 3b) Then request “top countries” for this service
            lifecycleScope.launch {
                viewModel.getServiceSpecificCountries(getString(R.string.smsActivate_api_key))
                viewModel.topCountriesResponse.observe(this@CountryActivity) { response ->
                    when (response) {
                        is NetworkResult.Success -> {
                            binding.loading.isVisible = false
                            val countries = response.data?.values
                            if (!countries.isNullOrEmpty()) {
                                Log.d("topCountriesCheck", "countries list size: ${countries.size}")
                                serviceSpecificAdapter.submitList(countries.toList())
                            } else {
                                Log.d("topCountriesCheck", "countries list is empty or null")
                            }
                        }

                        is NetworkResult.Error -> {
                            binding.loading.isVisible = false
                            Log.d("topCountriesCheck", "Error: ${response.message}")
                        }

                        is NetworkResult.Loading -> {
                            Log.d("RentFragment", "Loading rent services...")
                            binding.loading.isVisible = true
                        }
                    }
                }
            }
        }
    }

}
