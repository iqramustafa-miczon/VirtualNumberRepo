package com.example.virtualnumber.adapter

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.virtualnumber.R
import com.example.virtualnumber.activity.RentNumberActivity
import com.example.virtualnumber.model.ServiceSpecificCountry
import com.example.virtualnumber.room.CountryEntity
import com.example.virtualnumber.utils.AppPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ServiceSpecificCountryAdapter(
    private val context: Context,
    private val countryList: List<CountryEntity>
) : ListAdapter<ServiceSpecificCountry, ServiceSpecificCountryAdapter.ViewHolder>(
    ServiceSpecificCountryDiffCallback()
) {

    private var fullList: List<ServiceSpecificCountry> = emptyList()

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCountryName: TextView = itemView.findViewById(R.id.tvCountryName)
        val tvPrice: TextView = itemView.findViewById(R.id.tvPrice)
        val tvTotalCount: TextView = itemView.findViewById(R.id.tvTotalCount)
        val tvCoins: TextView = itemView.findViewById(R.id.tvCoins)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_service_specific_country, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val serviceCountry = getItem(position)

        // Existing country name setup
        CoroutineScope(Dispatchers.Default).launch {
            for (country in countryList) {
                if (country.countryCode == serviceCountry.countryCode) {
                    withContext(Dispatchers.Main) {
                        holder.tvCountryName.text = country.countryName
                    }
                    break
                }
            }
        }

        // Price and coins calculation
        val price = serviceCountry.price // Assuming price is Double
        holder.tvPrice.text = "Price: ${price}USD"

        val coins = when {
            price in 0.2..<0.5 -> 1   // 0.2 ≤ price < 0.5
            price in 0.5..<1.5 -> 4   // 0.5 ≤ price < 1.5
            price in 1.5..<4.0 -> 6   // 1.5 ≤ price < 4.0
            price in 4.0..<7.0 -> 8   // 4.0 ≤ price < 7.0
            price in 7.0..10.0 -> 10  // 7.0 ≤ price ≤ 10.0
            else -> 0                  // Handle out-of-range values
        }

        holder.tvCoins.text = coins.toString()

        // Rest of your existing code
        holder.tvTotalCount.text = "Available: ${serviceCountry.totalCount}"

        holder.itemView.setOnClickListener {
            // Your existing click handler
        }
    }

   /* override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val serviceCountry = getItem(position)

        CoroutineScope(Dispatchers.Default).launch {
            for (country in countryList) {
                if (country.countryCode == serviceCountry.countryCode) {
                    withContext(Dispatchers.Main) {
                        holder.tvCountryName.text = country.countryName
                    }
                    break
                }
            }
        }

        holder.tvPrice.text = "Price: ${serviceCountry.price} USD"
        holder.tvTotalCount.text = "Available: ${serviceCountry.totalCount}"

        holder.itemView.setOnClickListener {
            Log.d("service_specific_country_detail", "Code:  $serviceCountry.countryCode.toString()")
            AppPreferences.setCountryCode(serviceCountry.countryCode.toString())

            var countryName: String = "Unknown Country"
            for (country in countryList) {
                if (country.countryCode == serviceCountry.countryCode) {
                    countryName = country.countryName
                    break
                }
            }
            Log.d("service_specific_country_detail", "Name: $countryName")
            AppPreferences.setCountryName(countryName)

            val intent = Intent(context, RentNumberActivity::class.java).apply {
                putExtra("service_code", AppPreferences.getServiceCode())
                putExtra("country_code", serviceCountry.countryCode)
            }
            context.startActivity(intent)
        }
    }*/

    // Submit full list and keep a copy
    fun submitFullList(list: List<ServiceSpecificCountry>) {
        fullList = list
        submitList(fullList)
    }

    fun filter(query: String) {
        val filtered = if (query.isEmpty()) {
            fullList
        } else {
            fullList.filter { serviceCountry ->
                val countryName = countryList.find { it.countryCode == serviceCountry.countryCode }?.countryName ?: ""
                countryName.contains(query, ignoreCase = true)
            }
        }
        submitList(filtered.toList()) // Force ListAdapter to detect changes
    }

    class ServiceSpecificCountryDiffCallback : DiffUtil.ItemCallback<ServiceSpecificCountry>() {
        override fun areItemsTheSame(
            oldItem: ServiceSpecificCountry,
            newItem: ServiceSpecificCountry,
        ): Boolean {
            return oldItem.countryCode == newItem.countryCode
        }

        override fun areContentsTheSame(
            oldItem: ServiceSpecificCountry,
            newItem: ServiceSpecificCountry,
        ): Boolean {
            return oldItem == newItem
        }
    }
}
