package com.example.virtualnumber.fragment

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.virtualnumber.R
import com.example.virtualnumber.activity.CountryActivity
import com.example.virtualnumber.adapter.RentServiceAdapter
import com.example.virtualnumber.databinding.FragmentRentBinding
import com.example.virtualnumber.model.rent.RentService
import com.example.virtualnumber.remote.NetworkResult
import com.example.virtualnumber.room.CountryEntity
import com.example.virtualnumber.viewModel.VirtualNumberViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class RentFragment : Fragment() {

    private lateinit var binding: FragmentRentBinding

    private val viewModel: VirtualNumberViewModel by viewModels()

    // 1) Cache Room’s CountryEntity list
    private var cachedCountryList: List<CountryEntity> = emptyList()

    // 2) Cache the full list of rent‐services for search
    private var cachedServices: List<Map.Entry<String, RentService>> = emptyList()

    private lateinit var adapter: RentServiceAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentRentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.d("RentFragment", "onViewCreated called")

        // 1) Observe Room’s countries
        viewModel.allCountriesLiveData.observe(viewLifecycleOwner) { countryList ->
            cachedCountryList = countryList
            Log.d("RentFragment", "DB countries loaded (${countryList.size} items).")
            countryList.forEach { entity ->
                Log.d(
                    "RentFragment",
                    "  DB Entity → code=${entity.countryCode}, name=${entity.countryName}"
                )
            }
        }

        // 2) Observe rent‐services + countries response
        viewModel.rentServicesResponse.observe(viewLifecycleOwner) { result ->
            when (result) {
                is NetworkResult.Loading -> {
                    binding.loading.isVisible = true
                    Log.d("RentFragment", "Loading rent services + countries…")
                }

                is NetworkResult.Error -> {
                    binding.loading.isVisible = false
                    Log.e("RentFragment", "Error: ${result.message}")
                }

                is NetworkResult.Success -> {
                    binding.loading.isVisible = false

                    // a) Extract services entries & cache
                    val servicesList: List<Map.Entry<String, RentService>> =
                        result.data!!.services.entries.toList()
                    cachedServices = servicesList
                    Log.d("RentFragment", "Fetched ${servicesList.size} rent services")

                    // b) Initialize adapter (filteredList starts as fullList):
                    adapter = RentServiceAdapter(servicesList) { serviceCode ->
                        Log.d("RentFragment", "Service clicked: $serviceCode")

                        // MATCHING LOGIC: get API’s country IDs and filter cachedCountryList
                        val apiCountryIds: List<Int> =
                            result.data.countries.values.toList()
                        Log.d("RentFragment", "  API returned country IDs: $apiCountryIds")

                        val matchedEntities: List<CountryEntity> =
                            cachedCountryList.filter { entity ->
                                apiCountryIds.contains(entity.countryCode)
                            }
                        Log.d(
                            "RentFragment",
                            "  Matched ${matchedEntities.size} DB entities by ID"
                        )

                        val matchedNames: List<String> =
                            matchedEntities.map { it.countryName }
                        Log.d("RentFragment", "  Matched country names: $matchedNames")

                        // Launch CountryActivity with matchedNames & serviceCode
                        val intent = Intent(requireContext(), CountryActivity::class.java).apply {
                            putStringArrayListExtra(
                                "MATCHED_NAMES",
                                ArrayList(matchedNames)
                            )
                            putExtra("SERVICE_CODE", serviceCode)
                        }
                        startActivity(intent)
                    }

                    // c) Hook up RecyclerView
                    binding.rvRentServices.layoutManager = LinearLayoutManager(requireContext())
                    binding.rvRentServices.adapter = adapter

                    // d) Hide “No data” (because we just loaded data)
                    binding.tvNoData.isVisible = servicesList.isEmpty()
                }
            }
        }

        // 3) Trigger initial network calls
        viewModel.getRentServicesAndCountries(getString(R.string.smsActivate_api_key))
        viewModel.getCountries(getString(R.string.smsActivate_api_key))
        Log.d("RentFragment", "Requested rentServicesAndCountries and getCountries()")

        // 4) Wire up the search EditText
        setupSearchListener()
    }

    private fun setupSearchListener() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(
                s: CharSequence?, start: Int, count: Int, after: Int,
            ) {
                // no-op
            }

            override fun onTextChanged(
                s: CharSequence?, start: Int, before: Int, count: Int,
            ) {
                // no-op
            }

            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString()?.trim() ?: ""
                filterServices(query)
            }
        })
    }

    private fun filterServices(query: String) {
        // If adapter isn’t yet initialized (e.g., viewModel not returned data), do nothing
        if (!::adapter.isInitialized) return

        // 1) If query is empty → restore full list
        if (query.isEmpty()) {
            adapter.updateList(adapter.getFullList())
            binding.tvNoData.isVisible = adapter.getFullList().isEmpty()
            return
        }

        // 2) Otherwise filter by serviceCode or by some “name” in RentService
        val filtered: List<Map.Entry<String, RentService>> =
            adapter.getFullList().filter { entry ->
                val codeMatches = entry.key.contains(query, ignoreCase = true)
                // Assume RentService has a field “name” (or adjust to whatever text you want to match)
                val nameMatches = entry.value.search_name.contains(query, ignoreCase = true)
                codeMatches || nameMatches
            }

        // 3) Update adapter and toggle “No data”
        adapter.updateList(filtered)
        binding.tvNoData.isVisible = filtered.isEmpty()
    }
}

