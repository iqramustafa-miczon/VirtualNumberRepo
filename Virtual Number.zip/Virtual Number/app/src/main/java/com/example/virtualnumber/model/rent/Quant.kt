package com.example.virtualnumber.model.rent

data class Quant(
    val current: Int,
    val total: Int
)