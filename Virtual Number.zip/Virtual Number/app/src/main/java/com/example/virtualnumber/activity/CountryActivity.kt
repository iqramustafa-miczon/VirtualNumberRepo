package com.example.virtualnumber.activity

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.virtualnumber.R
import com.example.virtualnumber.adapter.CountryAdapter
import com.example.virtualnumber.adapter.RentCountryAdapter
import com.example.virtualnumber.adapter.ServiceSpecificCountryAdapter
import com.example.virtualnumber.databinding.ActivityCountryBinding
import com.example.virtualnumber.remote.NetworkResult
import com.example.virtualnumber.utils.AppPreferences
import com.example.virtualnumber.viewModel.VirtualNumberViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@AndroidEntryPoint
class CountryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCountryBinding
    private lateinit var adapter: CountryAdapter
    private lateinit var serviceSpecificAdapter: ServiceSpecificCountryAdapter
    private lateinit var rentCountryAdapter: RentCountryAdapter

    private val viewModel: VirtualNumberViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCountryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val serviceCode = intent.getStringExtra("serviceCode") ?: getString(R.string.unknown)
        val serviceName = intent.getStringExtra("serviceName") ?: getString(R.string.unknown)
        val serviceInfo = "$serviceName ($serviceCode)"

        //From specifically Rent Fragment
        val matchedNames: ArrayList<String>? = intent.getStringArrayListExtra("MATCHED_NAMES")
        val rentServiceCode = intent.getStringExtra("SERVICE_CODE")

        binding.tvTitle.text = serviceInfo
        AppPreferences.setServiceName(serviceName)

        binding.btnBack.setOnClickListener {
            finish()
        }

        if (!matchedNames.isNullOrEmpty()) {
            binding.loading.isVisible = false
            binding.rvCountries.layoutManager = LinearLayoutManager(this)

            rentCountryAdapter =
                RentCountryAdapter(this@CountryActivity, matchedNames, rentServiceCode.toString())
            binding.rvCountries.adapter = rentCountryAdapter

            return
        }

        if (serviceName == "Full rent") {

            Log.d("countryActivity", "In full rent block")

            binding.rvCountries.layoutManager = LinearLayoutManager(this)
            adapter = CountryAdapter(this) { isEmpty ->
                binding.tvNoData.isVisible = isEmpty
            }
            binding.rvCountries.adapter = adapter

            lifecycleScope.launch {
                viewModel.getCountries(getString(R.string.smsActivate_api_key))
                viewModel.countriesResponse.observe(this@CountryActivity) { response ->
                    when (response) {
                        is NetworkResult.Success -> {
                            binding.loading.isVisible = false
                            val countries = response.data?.values
                            if (!countries.isNullOrEmpty()) {
                                Log.d("countriesCheck", "countries list size: ${countries.size}")
                                adapter.submitList(countries.toList())
                            } else {
                                Log.d("countriesCheck", "countries list is empty or null")
                            }
                        }

                        is NetworkResult.Error -> {
                            binding.loading.isVisible = false
                            Log.d("countriesCheck", "Error: ${response.message}")
                        }

                        is NetworkResult.Loading -> {
                            Log.d("RentFragment", "Loading rent services...")
                            binding.loading.isVisible = true
                        }
                    }
                }
            }

        } else {

            Log.d("countryActivity", "In else, specific service search block")

            binding.rvCountries.layoutManager = LinearLayoutManager(this)
            serviceSpecificAdapter = ServiceSpecificCountryAdapter(emptyList())
            binding.rvCountries.adapter = serviceSpecificAdapter

            lifecycleScope.launch {
                viewModel.countries.collect { countriesList ->
                    withContext(Dispatchers.Main) {
                        binding.rvCountries.layoutManager =
                            LinearLayoutManager(this@CountryActivity)
                        serviceSpecificAdapter =
                            ServiceSpecificCountryAdapter(countriesList)
                        binding.rvCountries.adapter = serviceSpecificAdapter
                    }
                }
            }

            lifecycleScope.launch {
                viewModel.getServiceSpecificCountries(getString(R.string.smsActivate_api_key))
                viewModel.topCountriesResponse.observe(this@CountryActivity) { response ->
                    when (response) {
                        is NetworkResult.Success -> {
                            binding.loading.isVisible = false
                            val countries = response.data?.values
                            if (!countries.isNullOrEmpty()) {
                                Log.d(
                                    "countryActivity", " countries list size: ${countries.size}"
                                )
                                serviceSpecificAdapter.submitList(countries.toList())
                            } else {
                                Log.d(
                                    "countryActivity", " countries list is empty or null"
                                )
                            }
                        }

                        is NetworkResult.Error -> {
                            binding.loading.isVisible = false
                            Log.d(
                                "countryActivity", "Error: ${response.message}"
                            )
                        }

                        is NetworkResult.Loading -> {
                            binding.loading.isVisible = true
                            Log.d("countryActivity", "Loading countries...")
                        }
                    }
                }
            }
        }
    }

}
