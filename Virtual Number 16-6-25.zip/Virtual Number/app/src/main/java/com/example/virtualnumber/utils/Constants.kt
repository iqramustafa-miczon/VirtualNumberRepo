package com.example.virtualnumber.utils

object Constants {
    var COIN_COUNT = 0
}