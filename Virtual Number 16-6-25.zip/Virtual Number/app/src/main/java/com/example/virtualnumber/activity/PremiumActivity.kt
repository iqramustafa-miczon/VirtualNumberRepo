package com.example.virtualnumber.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.virtualnumber.databinding.ActivityPremiumBinding
import com.example.virtualnumber.utils.AppPreferences
import com.example.virtualnumber.utils.Constants.COIN_COUNT

class PremiumActivity : AppCompatActivity() {

    private val binding: ActivityPremiumBinding by lazy {
        ActivityPremiumBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.apply {
            coin1.setOnClickListener {
                COIN_COUNT = 1
            }
            coin4.setOnClickListener {
                COIN_COUNT = 4
            }
            coin6.setOnClickListener {
                COIN_COUNT = 6
            }
            coin8.setOnClickListener {
                COIN_COUNT = 8
            }
            coin10.setOnClickListener {
                COIN_COUNT = 10
            }
        }

    }
}