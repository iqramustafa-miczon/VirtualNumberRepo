package com.example.virtualnumber.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.addCallback
import androidx.activity.viewModels
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.virtualnumber.R
import com.example.virtualnumber.adapter.CountryAdapter
import com.example.virtualnumber.adapter.ServiceSpecificCountryAdapter
import com.example.virtualnumber.databinding.FragmentCountriesBinding
import com.example.virtualnumber.model.Country
import com.example.virtualnumber.remote.NetworkResult
import com.example.virtualnumber.viewModel.VirtualNumberViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@AndroidEntryPoint
class CountriesFragment : Fragment() {

    private lateinit var binding: FragmentCountriesBinding
    private lateinit var adapter: CountryAdapter
    private lateinit var serviceSpecificAdapter: ServiceSpecificCountryAdapter

    private val viewModel: VirtualNumberViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentCountriesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val serviceCode = arguments?.getString("serviceCode") ?: "Unknown Service Code"
        val serviceName = arguments?.getString("serviceName") ?: "Unknown Service Code"
        val countryInfo = "$serviceName($serviceCode)"
        binding.tvTitle.text = countryInfo

      if (serviceName == "Full rent") {

            binding.rvCountries.layoutManager = LinearLayoutManager(requireContext())
            adapter = CountryAdapter(requireContext())
            binding.rvCountries.adapter = adapter

            lifecycleScope.launch {
                viewModel.getCountries(getString(R.string.smsActivate_api_key))
                viewModel.countriesResponse.observe(viewLifecycleOwner) { response ->
                    when (response) {
                        is NetworkResult.Success -> {
                            val countries = response.data?.values
                            if (!countries.isNullOrEmpty()) {
                                Log.d("countriesCheck", "countries list size: ${countries.size}")
                                adapter.submitList(countries.toList())
                            } else {
                                Log.d("countriesCheck", "countries list is empty or null")
                            }
                        }

                        is NetworkResult.Error -> {
                            Log.d("countriesCheck", "Error: ${response.message}")
                        }
                    }
                }
            }
        } else {
            lifecycleScope.launch {

                lifecycleScope.launch {
                    viewModel.countries.collect { countries ->
                        withContext(Dispatchers.Main) {
                            binding.rvCountries.layoutManager = LinearLayoutManager(requireContext())
                            serviceSpecificAdapter = ServiceSpecificCountryAdapter(requireContext(), countries)
                            binding.rvCountries.adapter = serviceSpecificAdapter
                        }
                    }
                }

                viewModel.getServiceSpecificCountries(getString(R.string.smsActivate_api_key))
                viewModel.topCountriesResponse.observe(viewLifecycleOwner) { response ->
                    when (response) {
                        is NetworkResult.Success -> {
                            val countries = response.data?.values
                            if (!countries.isNullOrEmpty()) {
                                Log.d("topCountriesCheck", "countries list size: ${countries.size}")
                                serviceSpecificAdapter.submitList(countries.toList())
                            } else {
                                Log.d("topCountriesCheck", "countries list is empty or null")
                            }
                        }

                        is NetworkResult.Error -> {
                            Log.d("topCountriesCheck", "Error: ${response.message}")
                        }
                    }
                }
            }
        }

        binding.btnBack.setOnClickListener {
            requireActivity().supportFragmentManager.popBackStack()
        }
    }

    override fun onResume() {
        super.onResume()
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner) {
            requireActivity().supportFragmentManager.popBackStack()
        }
    }

}
