package com.example.virtualnumber.viewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.virtualnumber.model.Country
import com.example.virtualnumber.model.ServiceSpecificCountry
import com.example.virtualnumber.model.Services
import com.example.virtualnumber.remote.NetworkResult
import com.example.virtualnumber.repository.VirtualNumberRepository
import com.example.virtualnumber.room.CountryEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import org.json.JSONObject
import javax.inject.Inject

@HiltViewModel
class VirtualNumberViewModel @Inject constructor(
    private val repository: VirtualNumberRepository,
) : ViewModel() {

    private val _response: MutableLiveData<NetworkResult<Services>> = MutableLiveData()
    val response: LiveData<NetworkResult<Services>> = _response

    private val _countriesResponse: MutableLiveData<NetworkResult<Map<String, Country>>> =
        MutableLiveData()
    val countriesResponse: LiveData<NetworkResult<Map<String, Country>>> = _countriesResponse

    private val _topCountriesResponse: MutableLiveData<NetworkResult<Map<String, ServiceSpecificCountry>>> =
        MutableLiveData()
    val topCountriesResponse: LiveData<NetworkResult<Map<String, ServiceSpecificCountry>>> = _topCountriesResponse

    val countries = repository.countries

    fun insertCountries(countries: List<CountryEntity>) = viewModelScope.launch {
        repository.insertCountries(countries)
    }

    fun getServices(apiKey: String) = viewModelScope.launch {
        repository.getServices(apiKey).collect { values ->
            _response.value = values
        }
    }

    fun getCountries(apiKey: String) = viewModelScope.launch {
        repository.getCountries(apiKey).collect { values ->
            _countriesResponse.value = values
        }
    }

    fun getServiceSpecificCountries(apiKey: String) = viewModelScope.launch {
        repository.getServiceSpecificCountries(apiKey).collect { values ->
            _topCountriesResponse.value = values
        }
    }

    fun getNumber(
        apiKey: String,
        serviceCode: String,
        countryCode: String,
        callback: (String) -> Unit,
    ) {
        viewModelScope.launch {
            val number = repository.getNumber(apiKey, serviceCode, countryCode)
            callback(number)
        }
    }

    fun getBalance(apiKey: String, callback: (String) -> Unit) {
        viewModelScope.launch {
            val balance = repository.getBalance(apiKey)
            callback(balance)
        }
    }

    fun getNumbersStatus(
        apiKey: String,
        serviceCode: String?,
        countryCode: String?,
        callback: (String) -> Unit,
    ) {
        viewModelScope.launch {
            val status = repository.getNumbersStatus(apiKey, serviceCode, countryCode)
            if (status != null) {
                callback(status)
            }
        }
    }

    fun setStatus(apiKey: String, status: Int, activationId: String, callback: (String) -> Unit) {
        viewModelScope.launch {
            val result = repository.setStatus(apiKey, status, activationId)
            callback(result)
        }
    }

    /*fun getStatus(apiKey: String, activationId: String, callback: (String) -> Unit) {
        viewModelScope.launch {
            val status = repository.getStatus(apiKey, activationId)
            callback(status)
        }
    }*/

    fun getActiveActivations(apiKey: String, callback: (String) -> Unit) {
        viewModelScope.launch {
            val activations = repository.getActiveActivations(apiKey)
            callback(activations)
        }
    }

    /*fun getOperators(apiKey: String, countryCode: String, callback: (String) -> Unit) {
        viewModelScope.launch {
            val operators = repository.getOperators(apiKey, countryCode)
            callback(operators)
        }
    }*/

    /*fun getPrices(
        apiKey: String,
        serviceCode: String?,
        countryCode: String?,
        callback: (String) -> Unit,
    ) {
        viewModelScope.launch {
            val prices = repository.getPrices(apiKey, serviceCode, countryCode)
            callback(prices)
        }
    }*/
}
