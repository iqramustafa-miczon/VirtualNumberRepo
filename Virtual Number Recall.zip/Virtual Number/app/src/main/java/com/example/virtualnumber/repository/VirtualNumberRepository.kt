package com.example.virtualnumber.repository

import com.example.virtualnumber.model.Country
import com.example.virtualnumber.model.ServiceSpecificCountry
import com.example.virtualnumber.model.Services
import com.example.virtualnumber.remote.NetworkResult
import com.example.virtualnumber.remote.RemoteDataSource
import com.example.virtualnumber.retrofit.BaseApiResponse
import com.example.virtualnumber.room.CountryDao
import com.example.virtualnumber.room.CountryEntity
import dagger.hilt.android.scopes.ActivityRetainedScoped
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject

@ActivityRetainedScoped
class VirtualNumberRepository @Inject constructor(
    private val remoteDataSource: RemoteDataSource,
    private val countryDao: CountryDao
) : BaseApiResponse() {

    val countries: Flow<List<CountryEntity>> = countryDao.getCountries()

    suspend fun insertCountries(countries: List<CountryEntity>) = countryDao.insertCountries(countries)

    suspend fun getServices(apiKey: String): Flow<NetworkResult<Services>> {
        return flow {
            emit(safeApiCall {
                remoteDataSource.getServices(apiKey)
            })
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getCountries(apiKey: String): Flow<NetworkResult<Map<String, Country>>> {
        return flow {
            val response = safeApiCall { remoteDataSource.getCountries(apiKey) }
            emit(response)
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getServiceSpecificCountries(apiKey: String): Flow<NetworkResult<Map<String, ServiceSpecificCountry>>> {
        return flow {
            val response = safeApiCall { remoteDataSource.getServiceSpecificCountries(apiKey) }
            emit(response)
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getNumber(
        apiKey: String,
        serviceCode: String,
        countryCode: String,
    ): String {
        return remoteDataSource.getNumber(apiKey, serviceCode, countryCode)
    }

    suspend fun getNumbersStatus(
        apiKey: String,
        serviceCode: String?,
        countryCode: String?,
    ): String? {
        return remoteDataSource.getNumberStatus(apiKey, serviceCode, countryCode)
    }

    suspend fun getBalance(apiKey: String): String {
        return remoteDataSource.getBalance(apiKey)
    }

    suspend fun setStatus(apiKey: String, status: Int, activationId: String): String {
        return remoteDataSource.setStatus(apiKey, status.toString(), activationId)
    }


    suspend fun getActiveActivations(apiKey: String): String {
        return remoteDataSource.getActiveActivations(apiKey)
    }
}

