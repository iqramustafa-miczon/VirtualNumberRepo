package com.example.virtualnumber.adapter

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.virtualnumber.R
import com.example.virtualnumber.activity.RentNumberActivity
import com.example.virtualnumber.model.ServiceSpecificCountry
import com.example.virtualnumber.room.CountryEntity
import com.example.virtualnumber.utils.AppPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ServiceSpecificCountryAdapter(
    private val context: Context,
    private val countryList: List<CountryEntity>,
) :
    ListAdapter<ServiceSpecificCountry, ServiceSpecificCountryAdapter.ViewHolder>(
        ServiceSpecificCountryDiffCallback()
    ) {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCountryName: TextView = itemView.findViewById(R.id.tvCountryName)
        val tvPrice: TextView = itemView.findViewById(R.id.tvPrice)
        val tvTotalCount: TextView = itemView.findViewById(R.id.tvTotalCount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_service_specific_country, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val serviceCountry = getItem(position)

        CoroutineScope(Dispatchers.Default).launch {
            for (country in countryList) {
                if (country.countryCode == serviceCountry.countryCode) {
                    withContext(Dispatchers.Main) {
                        holder.tvCountryName.text = country.countryName
                    }
                    break
                }
            }
        }

        val price = "Price: ${serviceCountry.price} USD"
        holder.tvPrice.text = price

        val count = "Available: ${serviceCountry.totalCount}"
        holder.tvTotalCount.text = count

        holder.itemView.setOnClickListener {
            Log.d("service_country_code", serviceCountry.countryCode.toString())
            AppPreferences.setCountryCode(serviceCountry.countryCode.toString())

            val intent = Intent(context, RentNumberActivity::class.java).apply {
                putExtra("service_code", AppPreferences.getServiceCode())
                putExtra("country_code", serviceCountry.countryCode)
            }
            context.startActivity(intent)
        }
    }

    class ServiceSpecificCountryDiffCallback : DiffUtil.ItemCallback<ServiceSpecificCountry>() {
        override fun areItemsTheSame(
            oldItem: ServiceSpecificCountry,
            newItem: ServiceSpecificCountry,
        ): Boolean {
            return oldItem.countryCode == newItem.countryCode
        }

        override fun areContentsTheSame(
            oldItem: ServiceSpecificCountry,
            newItem: ServiceSpecificCountry,
        ): Boolean {
            return oldItem == newItem
        }
    }
}
