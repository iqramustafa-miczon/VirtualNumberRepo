package com.example.virtualnumber.activity

import android.os.Bundle
import android.util.Log
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.virtualnumber.R
import com.example.virtualnumber.databinding.ActivityRentNumberBinding
import com.example.virtualnumber.utils.App
import com.example.virtualnumber.utils.AppPreferences
import com.example.virtualnumber.viewModel.VirtualNumberViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class RentNumberActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRentNumberBinding
    private lateinit var viewModel: VirtualNumberViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRentNumberBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[VirtualNumberViewModel::class.java]

        val countryCode = AppPreferences.getCountryCode()
        val serviceCode = AppPreferences.getServiceCode()

        val countryName = AppPreferences.getCountryName()
        val serviceName = AppPreferences.getServiceName()

        Log.d("RENT_NUMBER", "Service Code: $serviceCode, Country Code: $countryCode")

        binding.tvServiceCode.text = serviceCode
        binding.tvServiceName.text = serviceName
        binding.tvCountryCode.text = countryCode
        binding.tvCountryName.text = countryName

        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnPurchaseNumber.setOnClickListener {
            lifecycleScope.launch {
                viewModel.getNumber(
                    getString(R.string.smsActivate_api_key),
                    serviceCode,
                    countryCode
                ) { response ->
                    // Check if the response starts with "ACCESS_NUMBER:"
                    if (response.startsWith("ACCESS_NUMBER:")) {
                        // Split the response by colon.
                        val parts = response.split(":")
                        // Expecting at least three parts: "ACCESS_NUMBER", activation id, and number.
                        if (parts.size >= 3) {
                            val activationId = parts[1]
                            val rentedNumber = parts[2]
                            Log.d("NUMBER_RENTED", "Activation ID: $activationId, Number: $rentedNumber")
                        } else {
                            Log.e("NUMBER_RENTED", "Unexpected format: $response")
                        }
                    } else {
                        // Handle error message cases
                        Log.e("NUMBER_RENTED_ERROR", response)
                    }
                }
            }
        }

        onBackPressedDispatcher.addCallback(onBackPressedCallback)
    }

    private val onBackPressedCallback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            finish()
        }
    }
}