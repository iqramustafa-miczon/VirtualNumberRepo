package com.example.virtualnumber.adapter

import androidx.annotation.StringRes
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter

class TabPagerAdapter(fragment: Fragment) : FragmentStateAdapter(fragment) {

    private val fragments = listOf(
        TabItem(ActivationsFragment(), R.string.activations),
        TabItem(RentFragment(), R.string.rent)
    )

    override fun getItemCount(): Int = fragments.size

    override fun createFragment(position: Int): Fragment = fragments[position].fragment

    fun getPageTitle(position: Int): String =
        fragment.requireContext().getString(fragments[position].titleRes)

    data class TabItem(val fragment: Fragment, @StringRes val titleRes: Int)
}